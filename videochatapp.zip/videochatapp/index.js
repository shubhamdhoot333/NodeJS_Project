const express =require("express");
const bodyParser =require("body-parser")
const socket = require("socket.io")
const app=express();
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extends:true}))

 const server = app.listen(3000,()=>{
    console.log("serve is running at 3000")
});
app.set("view engine","ejs")
app.set("view","./view")
app.use(express.static('public'))
const userRoute = require('./routes/userRoute')
app.use('/',userRoute);


//socket io working with signalling server
var io = socket(server);
io.on("connection",(socket)=>{
        console.log("socket connected i"+socket.id)
     
        socket.on("join",(roomName)=>{
           var rooms = io.sockets.adapter.rooms;
          var room =  rooms.get(roomName);
          if(room == undefined)
          {
            socket.join(roomName)
            socket.emit("created");
            // console.log("room created")
          }
          else if(room.size == 1) 
          {
            socket.join(roomName)
            socket.emit("joined");
            // console.log("room joined")

        }
          else  
          {
            socket.emit("full");
            // console.log("full")
          }
        })

        socket.on("ready",(roomName)=>{
            console.log("ready");
            socket.broadcast.to(roomName).emit("ready")

        })

        socket.on("candidate",(candidate,roomName)=>{
            console.log("candidate");
            socket.broadcast.to(roomName).emit("candidate",candidate)

        })
        socket.on("offer",(offer,roomName)=>{
            console.log("offer");
            socket.broadcast.to(roomName).emit("offer",offer)

        })
        socket.on("answer",(answer,roomName)=>{
            console.log("answer");
            socket.broadcast.to(roomName).emit("answer",answer)

        })
})
