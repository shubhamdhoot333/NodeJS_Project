var socket = io();
var videoChatForm = document.getElementById("video-chat-form");
var videoChatRooms = document.getElementById("video-chat-rooms");
var joinBtn = document.getElementById("join");
var roomInput = document.getElementById("roomName");
var userVideo = document.getElementById("user-video");
var peerVideo = document.getElementById("peer-video");
var roomName = roomInput.value
navigator.getUserMedia = navigator.getUserMedia ||
                                 navigator.webkitGetUserMedia ||
                                 navigator.mozGetUserMedia ||
                                 navigator.msGetUserMedia;

var creater = false ;
joinBtn.addEventListener("click",()=>{
    if(roomInput.value == "")
    {
        alert("please enter room name ")
    }
    else{
        socket.emit("join",roomName.value )  
        
      
    }
})

socket.on("created",()=>{
    creater = true;
    navigator.getUserMedia(
        {
            audio:true,
            video:true
        },
        function(stream){
            videoChatForm.style="display:none";
            userVideo.srcObject = stream;
            userVideo.onloadedmetadata = function(e){
                userVideo.play()
            }
        },
        function(error){
            alert("you cannot access media ");

        }  
    )
})
socket.on("joined",()=>{
    creater = false;
    navigator.getUserMedia(
        {
            audio:true,
            video:true
        },
        function(stream){
            videoChatForm.style="display:none";
            userVideo.srcObject = stream;
            userVideo.onloadedmetadata = function(e){
                userVideo.play()
            }
        },
        function(error){
            alert("you cannot access media ");

        }  
    )
})
socket.on("full",()=>{
    alert("room is full you cannot joined");
})
socket.on("ready",()=>{})
socket.on("candidate",()=>{})
socket.on("offer",()=>{})
socket.on("answer",()=>{})