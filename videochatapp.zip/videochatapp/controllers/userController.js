const loadIndex = (req,res) =>{
 
    try{
        console.log("come here");
        res.render('index')
    }
    catch(error)
    {
        console.log("message ",error)
    }
}

module.exports={
    loadIndex
}